# 🇧🇷 Bot-EB

Bot para comunidades de roleplay militar no Discord, com comandos slash e uma página HTTP de status.

## Requisitos

- Node.js 20 ou superior
- Uma aplicação e um bot criados no Discord Developer Portal

## Configuração

1. Instale as dependências com `npm install`.
2. Configure as variáveis de ambiente no painel de segredos da hospedagem:
   - `DISCORD_TOKEN`: token privado do bot
   - `CLIENT_ID`: Application ID da aplicação Discord
   - `GUILD_ID`: opcional; ID de um servidor para registrar comandos de teste
   - `PORT`: opcional; normalmente fornecido pela hospedagem
3. Registre os comandos executando `npm run deploy-commands`.
4. Inicie com `npm start`.

Nunca publique seu token ou o arquivo `.env` no GitHub. Use `.env.example` como modelo.

## Comandos incluídos

- `/ajuda`
- `/hierarquia`
- `/patente`
- `/ping`
- `/anunciar` (Administrador)
- `/advertir` (Moderar membros)
- `/banir` (Banir membros)

A lista de patentes em `comandos/info/hierarquia.js` e `comandos/info/patente.js` é um exemplo. Ajuste-a aos cargos reais do seu servidor.

## Endpoints web

- `/`: página de status do Bot-EB
- `/health`: JSON de saúde do servidor web e estado da conexão do bot

O endpoint `/health` não é uma verificação de segurança nem garante que todos os comandos estejam funcionando.

## Segurança

- Não inclua segredos em arquivos versionados.
- Dê ao bot somente as permissões necessárias.
- Teste comandos de moderação em um servidor de teste.
- O provedor de hospedagem deve expor o servidor web por HTTPS e manter o processo ativo conforme o plano contratado.
