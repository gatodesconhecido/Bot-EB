require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");
const { REST, Routes } = require("discord.js");

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || !clientId) {
  console.error("Configure DISCORD_TOKEN e CLIENT_ID antes de registrar os comandos.");
  process.exit(1);
}

const commands = [];

function collect(directory) {
  if (!fs.existsSync(directory)) return;

  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      collect(fullPath);
    } else if (entry.isFile() && entry.name.endsWith(".js")) {
      const command = require(fullPath);
      if (command.data?.toJSON) commands.push(command.data.toJSON());
    }
  }
}

collect(path.join(__dirname, "comandos"));

const rest = new REST({ version: "10" }).setToken(token);

(async () => {
  try {
    if (guildId) {
      console.log(`Registrando ${commands.length} comandos no servidor de teste ${guildId}...`);
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
    } else {
      console.log(`Registrando ${commands.length} comandos globalmente...`);
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
    }
    console.log("Comandos registrados com sucesso.");
  } catch (error) {
    console.error("Falha ao registrar comandos:", error);
    process.exitCode = 1;
  }
})();
