const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Verifica a latência do Bot-EB"),

  async execute(interaction, client) {
    await interaction.reply({
      content: `Pong! Latência da API: ${Math.round(client.ws.ping)} ms.`,
      ephemeral: true
    });
  }
};
