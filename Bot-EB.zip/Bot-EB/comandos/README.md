Cada arquivo JavaScript dentro das pastas de `comandos/` deve exportar `data` (um SlashCommandBuilder) e `execute(interaction, client)`. O carregador lê as subpastas recursivamente.
