const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("anunciar")
    .setDescription("Publica um anúncio oficial")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption(option =>
      option.setName("canal")
        .setDescription("Canal onde o anúncio será enviado")
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("titulo")
        .setDescription("Título do anúncio")
        .setMaxLength(200)
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("mensagem")
        .setDescription("Conteúdo do anúncio")
        .setMaxLength(4000)
        .setRequired(true)
    ),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: "Você precisa da permissão Administrador.", ephemeral: true });
    }

    const channel = interaction.options.getChannel("canal");
    const title = interaction.options.getString("titulo");
    const message = interaction.options.getString("mensagem");

    if (!channel?.isTextBased() || !channel.send) {
      return interaction.reply({ content: "Escolha um canal de texto válido.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x1f6b43)
      .setTitle(`🇧🇷 ${title}`)
      .setDescription(message)
      .setFooter({ text: `Anúncio oficial • ${interaction.guild.name}` })
      .setTimestamp();

    try {
      await channel.send({ embeds: [embed] });
      await interaction.reply({ content: `Anúncio enviado em ${channel}.`, ephemeral: true });
    } catch {
      await interaction.reply({ content: "Não consegui enviar. Confira as permissões do bot nesse canal.", ephemeral: true });
    }
  }
};
