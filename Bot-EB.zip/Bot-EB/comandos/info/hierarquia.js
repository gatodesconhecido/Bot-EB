const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

// Exemplo inicial. Edite esta lista para corresponder aos cargos reais do seu EB.
const PATENTES = [
  "Marechal",
  "General de Exército",
  "General de Divisão",
  "General de Brigada",
  "Coronel",
  "Tenente-Coronel",
  "Major",
  "Capitão",
  "1º Tenente",
  "2º Tenente",
  "Aspirante a Oficial",
  "Subtenente",
  "1º Sargento",
  "2º Sargento",
  "3º Sargento",
  "Cabo",
  "Soldado",
  "Recruta"
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("hierarquia")
    .setDescription("Mostra a hierarquia configurada do EB"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x1f6b43)
      .setTitle("🇧🇷 Hierarquia do EB")
      .setDescription(PATENTES.map((patente, i) => `**${i + 1}.** ${patente}`).join("\n"))
      .setFooter({ text: "Lista de exemplo: personalize conforme a hierarquia oficial do seu grupo." });

    await interaction.reply({ embeds: [embed] });
  }
};
