const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ajuda")
    .setDescription("Mostra os comandos disponíveis do Bot-EB"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x1f6b43)
      .setTitle("🇧🇷 Bot-EB | Central de Ajuda")
      .setDescription("Comandos disponíveis:")
      .addFields(
        { name: "/ajuda", value: "Mostra esta ajuda.", inline: false },
        { name: "/hierarquia", value: "Mostra uma hierarquia ilustrativa configurável.", inline: false },
        { name: "/patente", value: "Consulta a patente com base nos cargos do membro.", inline: false },
        { name: "/ping", value: "Verifica a latência do bot.", inline: false },
        { name: "/anunciar", value: "Publica um anúncio; exige permissão de Administrador.", inline: false },
        { name: "/advertir", value: "Registra uma advertência; exige permissão de Moderar membros.", inline: false },
        { name: "/banir", value: "Bane um membro; exige permissão de Banir membros.", inline: false }
      )
      .setFooter({ text: "Configure os cargos e as permissões para sua comunidade." });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
