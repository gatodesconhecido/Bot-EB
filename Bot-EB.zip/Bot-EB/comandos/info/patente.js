const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

// Ajuste os nomes para corresponder exatamente aos cargos do seu servidor.
const PATENTES = [
  "Marechal",
  "General de Exército",
  "General de Divisão",
  "General de Brigada",
  "Coronel",
  "Tenente-Coronel",
  "Major",
  "Capitão",
  "1º Tenente",
  "2º Tenente",
  "Aspirante a Oficial",
  "Subtenente",
  "1º Sargento",
  "2º Sargento",
  "3º Sargento",
  "Cabo",
  "Soldado",
  "Recruta"
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("patente")
    .setDescription("Consulta a patente de um membro")
    .addUserOption(option =>
      option.setName("membro")
        .setDescription("Membro que deseja consultar (opcional)")
        .setRequired(false)
    ),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      return interaction.reply({ content: "Use este comando dentro de um servidor.", ephemeral: true });
    }

    const user = interaction.options.getUser("membro") || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: "Não consegui localizar esse membro.", ephemeral: true });
    }

    const rank = PATENTES.find(patente =>
      member.roles.cache.some(role => role.name.toLowerCase() === patente.toLowerCase())
    );

    const embed = new EmbedBuilder()
      .setColor(0x1f6b43)
      .setTitle("Consulta de Patente")
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: "Membro", value: `${user}`, inline: true },
        { name: "Patente identificada", value: rank || "Nenhuma patente configurada foi encontrada.", inline: true },
        { name: "ID do Discord", value: user.id, inline: false }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
