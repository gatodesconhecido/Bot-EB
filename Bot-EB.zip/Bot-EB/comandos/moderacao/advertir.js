const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("advertir")
    .setDescription("Registra uma advertência e tenta avisar o membro por DM")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(option => option.setName("membro").setDescription("Membro advertido").setRequired(true))
    .addStringOption(option => option.setName("motivo").setDescription("Motivo da advertência").setMaxLength(1000).setRequired(true)),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: "Você precisa da permissão Moderar membros.", ephemeral: true });
    }

    const user = interaction.options.getUser("membro");
    const reason = interaction.options.getString("motivo");
    if (user.id === interaction.user.id) {
      return interaction.reply({ content: "Você não pode advertir a si mesmo.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xe0a020)
      .setTitle("Advertência registrada")
      .addFields(
        { name: "Membro", value: `${user} (${user.id})` },
        { name: "Responsável", value: `${interaction.user}` },
        { name: "Motivo", value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
    await user.send(`Você recebeu uma advertência em **${interaction.guild.name}**.\nMotivo: ${reason}`).catch(() => {});
  }
};
