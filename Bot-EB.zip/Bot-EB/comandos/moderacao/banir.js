const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("banir")
    .setDescription("Bane um membro do servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(option => option.setName("membro").setDescription("Membro que será banido").setRequired(true))
    .addStringOption(option => option.setName("motivo").setDescription("Motivo do banimento").setMaxLength(1000).setRequired(true)),

  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) {
      return interaction.reply({ content: "Você precisa da permissão Banir membros.", ephemeral: true });
    }

    const user = interaction.options.getUser("membro");
    const reason = interaction.options.getString("motivo");

    if (user.id === interaction.user.id) {
      return interaction.reply({ content: "Você não pode banir a si mesmo.", ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: "O membro não está neste servidor.", ephemeral: true });
    }
    if (!member.bannable) {
      return interaction.reply({ content: "Não consigo banir esse membro. Confira a hierarquia de cargos e as permissões do bot.", ephemeral: true });
    }

    await member.ban({ reason: `${reason} | Responsável: ${interaction.user.tag}` });
    await interaction.reply({ content: `Membro ${user.tag} banido.\nMotivo: ${reason}` });
  }
};
