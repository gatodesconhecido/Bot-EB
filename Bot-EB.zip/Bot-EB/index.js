require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");
const express = require("express");
const {
  Client,
  Collection,
  GatewayIntentBits,
  Events
} = require("discord.js");

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error("ERRO: configure DISCORD_TOKEN nas variáveis de ambiente.");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

client.commands = new Collection();

function loadCommands(directory) {
  if (!fs.existsSync(directory)) return;

  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);

    if (entry.isDirectory()) {
      loadCommands(fullPath);
      continue;
    }

    if (!entry.isFile() || !entry.name.endsWith(".js")) continue;

    try {
      const command = require(fullPath);
      if (command.data?.name && typeof command.execute === "function") {
        client.commands.set(command.data.name, command);
        console.log(`Comando carregado: /${command.data.name}`);
      } else {
        console.warn(`Comando ignorado (formato inválido): ${fullPath}`);
      }
    } catch (error) {
      console.error(`Falha ao carregar ${fullPath}:`, error);
    }
  }
}

loadCommands(path.join(__dirname, "comandos"));

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Bot conectado como ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    await interaction.reply({
      content: "Esse comando não está carregado. Avise a administração.",
      ephemeral: true
    }).catch(() => {});
    return;
  }

  try {
    await command.execute(interaction, client);
  } catch (error) {
    console.error(`Erro em /${interaction.commandName}:`, error);
    const response = {
      content: "Ocorreu um erro ao executar o comando.",
      ephemeral: true
    };

    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(response).catch(() => {});
    } else {
      await interaction.reply(response).catch(() => {});
    }
  }
});

// Servidor HTTP para hospedagem e verificações de disponibilidade.
// A hospedagem deve fornecer HTTPS publicamente.
const app = express();
app.disable("x-powered-by");

app.get("/", (_req, res) => {
  res.status(200).type("html").send(`<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bot-EB</title>
<style>
body{font-family:Arial,sans-serif;max-width:680px;margin:12vh auto;padding:24px;line-height:1.6;color:#17202a}
main{border:1px solid #ddd;border-radius:16px;padding:28px}
small{color:#667085}
</style>
</head>
<body><main>
<h1>🇧🇷 Bot-EB</h1>
<p>Servidor web do Bot-EB está respondendo.</p>
<p><a href="/health">Verificar estado do servidor</a></p>
<small>Esta página não confirma, sozinha, se o bot está conectado ao Discord.</small>
</main></body></html>`);
});

app.get("/health", (_req, res) => {
  res.status(200).json({
    projeto: "Bot-EB",
    servidorWeb: "online",
    botDiscord: client.isReady() ? "conectado" : "iniciando_ou_desconectado",
    horario: new Date().toISOString()
  });
});

app.get("/favicon.ico", (_req, res) => res.status(204).end());

const port = Number(process.env.PORT) || 3000;
app.listen(port, "0.0.0.0", () => {
  console.log(`Servidor Express iniciado na porta ${port}`);
});

client.login(token).catch((error) => {
  console.error("Não foi possível conectar o bot ao Discord. Confira DISCORD_TOKEN.", error.message);
  process.exit(1);
});
